'use strict';

exports.handler = (event, context, callback) => {
    const request = event.Records[0].cf.request;
    // var originReqPath = "/index.html"
    // console.log("Path result: " + originReqPath)
    // request.uri = originReqPath
    console.log("Path result: " + request.uri)
    callback(null, request);
};